<?php
// Text
$_['text_title'] = 'Pay Rest On Delivery';
$_['prod_text_opt'] = 'Pay Rest On Delivery';
$_['prod_text_total'] = 'Pay Rest On Delivery (%s)';